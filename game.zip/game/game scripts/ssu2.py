import pygame
import random
import sys

pygame.init()


WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Catching L's outside of electric circuits 2.0")
clock = pygame.time.Clock()


BLACK = (0, 0, 0)

player_speed = 20

player_image = pygame.image.load("gameii/game5.png")
player_image = pygame.transform.scale(player_image, (100, 100))
player_rect = player_image.get_rect()
player_rect.x = WIDTH // 2 - player_rect.width // 2
player_rect.y = HEIGHT - player_rect.height - 20

element_image = pygame.image.load("gameii/game10.png")
element_image = pygame.transform.scale(element_image, (80, 80))
element_width = element_image.get_width()
element_height = element_image.get_height()

bomb_image = pygame.image.load("gameii/bomb.png")
bomb_image = pygame.transform.scale(bomb_image, (80, 80))
bomb_width = bomb_image.get_width()
bomb_height = bomb_image.get_height()

heart_image = pygame.image.load("gameii/game15.png")
heart_image = pygame.transform.scale(heart_image, (40, 40))

start_screen = pygame.image.load("gameii/game17.png")
start_screen = pygame.transform.scale(start_screen, (WIDTH, HEIGHT))

start_button_image = pygame.image.load("gameii/game14.png")
start_button_rect = start_button_image.get_rect(topleft=(130, 300))
end_screen = pygame.image.load("gameii/game18.png")
end_screen = pygame.transform.scale(end_screen, (WIDTH, HEIGHT))

background = pygame.image.load("gameii/game19.jpeg")
background = pygame.transform.scale(background, (WIDTH, HEIGHT))
cursor_image = pygame.image.load("gameii/game19.png")
cursor_image = pygame.transform.scale(cursor_image, (30, 30))  
pygame.mouse.set_visible(False)




pygame.mixer.init()
audio4 = pygame.mixer.Sound("audio/audi1.mp3")
audio2 = pygame.mixer.Sound("audio/audi2.mp3")
audio3 = pygame.mixer.Sound("audio/audi3.mp3")
audio1 = pygame.mixer.Sound("audio/audi4.mp3")
audio5 = pygame.mixer.Sound("audio/audi5.mp3")


element_speed = 5
bomb_speed = 10
elements = []
bombs = []

score = 0
lives = 3

font = pygame.font.SysFont('fixedsys', 36)

running = True
game_state = "start"  

def draw_player(x, y):
    screen.blit(player_image, (x, y))

def draw_element(x, y):
    screen.blit(element_image, (x, y))

def draw_bomb(x, y):
    screen.blit(bomb_image, (x, y))

def check_collision(player_rect, rects):
    return any(player_rect.colliderect(rect) for rect in rects)

def show_game_over():
    screen.blit(end_screen, (0, 0))
    score_text = font.render(f"Score: {score}", True, BLACK)
    screen.blit(score_text, (WIDTH // 2 - score_text.get_width() // 2, HEIGHT // 2))

def show_start_screen():
    screen.blit(start_screen, (0, 0))
    screen.blit(start_button_image, start_button_rect)

def draw_lives(lives):
    for i in range(lives):
        screen.blit(heart_image, (WIDTH - (i + 1) * 50, 10))

audio1.play(loops=-1)  

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if game_state == "start" and event.type == pygame.MOUSEBUTTONDOWN:
            if start_button_rect.collidepoint(event.pos):
                game_state = "playing"
                score = 0
                lives = 3
                elements.clear()
                bombs.clear()
                player_rect.x = WIDTH // 2 - player_rect.width // 2
                audio1.stop()  
                audio2.play(loops=-1)  
    if game_state == "start":
        show_start_screen()

    elif game_state == "playing":
        screen.blit(background, (0, 0))

        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and player_rect.x > 0:
            player_rect.x -= player_speed
        if keys[pygame.K_RIGHT] and player_rect.x < WIDTH - player_rect.width:
            player_rect.x += player_speed

        if random.randint(1, 40) == 1:
            element_x = random.randint(0, WIDTH - element_width)
            elements.append([element_x, -element_height])

        if random.randint(1, 100) == 1:
            bomb_x = random.randint(0, WIDTH - bomb_width)
            bombs.append([bomb_x, -bomb_height])

        for element in elements[:]:
            element[1] += element_speed
            if element[1] > HEIGHT:
                elements.remove(element)
            else:
                element_rect = pygame.Rect(element[0], element[1], element_width, element_height)
                if check_collision(player_rect, [element_rect]):
                    score += 1
                    elements.remove(element)

        for bomb in bombs[:]:
            bomb[1] += bomb_speed
            if bomb[1] > HEIGHT:
                bombs.remove(bomb)
            else:
                bomb_rect = pygame.Rect(bomb[0], bomb[1], bomb_width, bomb_height)
                if check_collision(player_rect, [bomb_rect]):
                    if lives>1:
                        audio5.play()
                    lives -= 1  
                    bombs.remove(bomb)
                    if lives == 0:  
                        audio2.stop()  
                        audio3.play()  
                        game_state = "end"

        draw_player(player_rect.x, player_rect.y)
        for element in elements:
            draw_element(element[0], element[1])
        for bomb in bombs:
            draw_bomb(bomb[0], bomb[1])

        draw_lives(lives)

        score_text = font.render(f"Score: {score}", True, BLACK)
        screen.blit(score_text, (10, 10))

    elif game_state == "end":
        if not pygame.mixer.get_busy():  
            audio4.play(loops=-1)  
        show_game_over()
    mouse_x, mouse_y = pygame.mouse.get_pos()
    screen.blit(cursor_image, (mouse_x, mouse_y))
    pygame.display.flip()
    
    clock.tick(60)

pygame.quit()
sys.exit()
